import 'package:flutter/material.dart';

import 'components/navigation_bar.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  List<String> title = ['Schoolwork:', 'Workout', 'Mindfulness'];
  List<String> value = ['8 h 43 mins', '2 h 12 mins', '4 mins'];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        bottomNavigationBar: navigationBar(),
        backgroundColor: Color(0xFFE5E6D6),
        body: ListView(
          children: [
            Padding(
              padding: EdgeInsets.symmetric(vertical: 98.0, horizontal: 32.0),
              child: Container(
                width: 300,
                height: 100,
                decoration: const BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                    color: Color(0xFF6F8B78)),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    RichText(
                        textAlign: TextAlign.center,
                        text: const TextSpan(
                            text: 'Welcome back,',
                            style: TextStyle(
                                fontSize: 16,
                                color: Colors.white,
                                fontWeight: FontWeight.w300),
                            children: [
                              TextSpan(
                                text: ' Yasemin!',
                                style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700),
                              ),
                            ])),
                    const SizedBox(
                      height: 10,
                    ),
                    RichText(
                        textAlign: TextAlign.center,
                        text: const TextSpan(
                            text: 'Today is',
                            style: TextStyle(
                                fontSize: 16,
                                color: Colors.white,
                                fontWeight: FontWeight.w300),
                            children: [
                              TextSpan(
                                text: ' Sunday, 2nd July,',
                                style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700),
                              ),
                            ])),
                  ],
                ),
              ),
            ),
            InkWell(
              onTap: () {
                print('Add profile photo clicked');
              },
              child: Container(
                height: 125,
                width: 125,
                decoration: const BoxDecoration(
                  color: Color(0xFF6F8B78),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black,
                      blurRadius: 4,
                      offset: Offset(1, 2), // Shadow position
                    ),
                  ],
                ),
                child: const Center(
                  child: Text(
                    'Add profile photo',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                        fontWeight: FontWeight.w500),
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            const CircleAvatar(
                backgroundColor: Color(0xFFC96466),
                radius: 75,
                child: CircleAvatar(
                  radius: 60,
                  backgroundColor: Color(0xFF6F8B78),
                  child: Text(
                    'Your habits',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 14,
                        color: Colors.white,
                        fontWeight: FontWeight.w300),
                  ),
                )),
            Container(
              height: 350,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(36),
                      topRight: Radius.circular(36)),
                  color: Color(0xFF90A498)),
              child: Column(
                children: [
                  const Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text(
                      'Last week',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 18,
                          color: Colors.white,
                          fontWeight: FontWeight.w700),
                    ),
                  ),
                  ListView.builder(
                      itemCount: title.length,
                      physics: NeverScrollableScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.only(
                              top: 18.0, left: 25, right: 90),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                title[index],
                                style: const TextStyle(
                                    fontSize: 18,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w200),
                              ),
                              Text(
                                value[index],
                                style: const TextStyle(
                                    fontSize: 18,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700),
                              )
                            ],
                          ),
                        );
                      }),
                ],
              ),
            )
          ],
        ));
  }
}
