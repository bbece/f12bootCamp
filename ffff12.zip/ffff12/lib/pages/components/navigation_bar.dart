import 'package:ffff12/pages/profile_page.dart';
import 'package:flutter/material.dart';

import '../addHobby_page.dart';
import '../calendar_page.dart';

class navigationBar extends StatefulWidget {
  const navigationBar({Key? key}) : super(key: key);

  @override
  State<navigationBar> createState() => _navigationBarState();
}

class _navigationBarState extends State<navigationBar> {
  int currentPageIndex = 0;
  //widget options maine alınıp body de o gösterilecek tıklanınca
  final List<Widget> _widgetOptions = <Widget>[
    ProfilePage(),
    AddHobby(),
    CalendarPage(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      currentPageIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profil',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_month),
            label: 'Takvimim',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_circle_outline),
            label: 'Ekleme',
          ),
        ],
        currentIndex: currentPageIndex,
        selectedItemColor: Color(0xFF6F8B78),
        onTap: _onItemTapped,
      ),
    );
  }
}
