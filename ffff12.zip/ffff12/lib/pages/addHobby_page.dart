import 'package:flutter/material.dart';

class AddHobby extends StatefulWidget {
  const AddHobby({Key? key}) : super(key: key);

  @override
  State<AddHobby> createState() => _AddHobbyState();
}

class _AddHobbyState extends State<AddHobby> {
  bool _pinned = true;
  bool _snap = false;
  bool _floating = false;
  List<String> hobbies = [];

  void adding(String hobby) {
    setState(() {
      hobbies.add(hobby);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: <Widget>[
          SliverAppBar(
            backgroundColor: Color(0xFF6F8B78),
            pinned: _pinned,
            snap: _snap,
            floating: _floating,
            expandedHeight: 160.0,
            flexibleSpace: const FlexibleSpaceBar(
              title: Text('Add Hobby'),
            ),
          ),
          SliverGrid(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, // Number of columns in the grid
              mainAxisSpacing: 20.0, // Spacing between rows
              childAspectRatio: 5.0, // Width to height ratio of each item
            ),
            delegate: SliverChildBuilderDelegate(
              (BuildContext context, int index) {
                // Create a function that returns the ElevatedButton for each hobby
                return Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 8.0, horizontal: 50),
                  child: ElevatedButton(
                    style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all<Color>(
                            Color(0xFF6F8B78))),
                    onPressed: () {
                      adding(hobbiesList[index]);
                    },
                    child: Text(hobbiesList[index]),
                  ),
                );
              },
              childCount: hobbiesList.length, // Number of hobby buttons
            ),
          ),
        ],
      ),
        bottomNavigationBar :const navigationBar()
    );
  }
}

List<String> hobbiesList = [
  "Yüzme",
  "Koşu",
  "Kitap Okuma",
  "Spor Yapma",
];
