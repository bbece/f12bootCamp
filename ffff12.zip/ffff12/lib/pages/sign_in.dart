import 'package:ffff12/pages/log_in.dart';
import 'package:ffff12/pages/profile_page.dart';
import 'package:flutter/material.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Color(0xffE5E6D6),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: height * .15,
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    fit: BoxFit.cover,
                    image: AssetImage("assets/images/mint.jpg"),
                  ),
                ),
              ),
              customSizeBox(),
              Text(
                'KAYIT OL',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: Color(0xff6F8B78),
                ),
              ),
              customSizeBox(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextFormField(
                      decoration: customInputDecoration("NAME AND SURNAME"),
                    ),
                    customSizeBox(),
                    TextFormField(
                      decoration: customInputDecoration("E-MAIL"),
                    ),
                    customSizeBox(),
                    TextFormField(
                      decoration: customInputDecoration("PASSWORD"),
                    ),
                    customSizeBox(),
                    Center(
                        child: ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (context) => ProfilePage(),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Color(0xffC96466)),
                      child: Text("SIGN UP",
                          style: TextStyle(
                              color: Color.fromARGB(255, 232, 227, 227))),
                    )),
                    customSizeBox(),
                    Center(
                        child: TextButton(
                      onPressed: () {},
                      child: Text("Already have an account?",
                          style: TextStyle(color: Color(0xff6F8B78))),
                    )),
                    customSizeBox(),
                    Center(
                        child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => LoginPage()),
                        );
                      },
                      child: Text("LOG IN",
                          style: TextStyle(
                              color: Color.fromARGB(255, 232, 227, 227))),
                    )),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget customSizeBox() => SizedBox(
        height: 20,
      );

  Widget customSizeBox2() => SizedBox(
        height: 100,
      );
  InputDecoration customInputDecoration(String labelText) {
    return InputDecoration(
      labelText: labelText,
      focusedBorder: OutlineInputBorder(
        //borderSide: BorderSide(color: Colors.black),
        borderSide: BorderSide(color: Color(0xff6F8B78)),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      //labelText: "E-mail",
      //labelStyle: TextStyle(color: Colors.black),
      labelStyle: TextStyle(color: Color(0xffCF8A8A)),
      border: OutlineInputBorder(),
    );
  }
}
