import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

import 'components/navigation_bar.dart';

class CalendarPage extends StatefulWidget {
  const CalendarPage({Key? key}) : super(key: key);

  @override
  State<CalendarPage> createState() => _CalendarPageState();
}

class _CalendarPageState extends State<CalendarPage> {
  DateTime selectedDate = DateTime.now();
  Map<DateTime, List<String>> events = {};
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF6F8B78),
        title: Text('Calendar App'),
      ),
      body: Column(
        children: [
          TableCalendar(
            firstDay: DateTime.utc(DateTime.now().year - 1),
            lastDay: DateTime.utc(DateTime.now().year + 1),
            focusedDay: DateTime.now(),
            selectedDayPredicate: (day) {
              return isSameDay(selectedDate, day);
            },
            onDaySelected: (selectedDay, focusedDay) {
              setState(() {
                selectedDate = selectedDay;
              });
            },
            eventLoader: (day) {
              return events[day] ??
                  []; // Takvimdeki o güne ait metin bilgisini getir
            },
          ),
          SizedBox(height: 20),
          Text(
            'Bu tarih: ${selectedDate != null ? selectedDate.toString() : null}',
            style: TextStyle(fontSize: 20),
          ),
          SizedBox(height: 20),
          TextFormField(
            decoration: InputDecoration(
              labelText: 'Günlük planınızı girebilirsiniz',
            ),
            onChanged: (text) {
              setState(() {
                if (selectedDate != null) {
                  if (events.containsKey(selectedDate)) {
                    events[selectedDate]!.add(text);
                  } else {
                    events[selectedDate] = [text];
                  }
                }
              });
              // Handle the text input
            },
          ),
        ],

      ),
      bottomNavigationBar :const navigationBar(),
      );
  }
}
